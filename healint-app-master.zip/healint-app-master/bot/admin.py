from django.contrib import admin
from bot.models import Disease

admin.site.register(Disease)
# Register your models here.
