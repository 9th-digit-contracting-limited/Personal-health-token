# healint-app
Healint is a way to assist doctors and patients in disease diagnosis and their treatment. It has a doctor bot which interacts with patients and finally predict the disease. Other than this it also has location based hospital recommendation system. It also facilitates in knowing your BMI and getting a diet chart.

HOSTED ON AWS 1year free server (ip not shared)

and also on http://goyaljai.pythonanywhere.com/

google playstore link - https://play.google.com/store/apps/details?id=com.khome.darkwolve.heliant
