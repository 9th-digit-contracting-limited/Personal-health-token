//require config.js

requirejs.config({
    baseUrl:'genHealthAPI',
    paths:{
        app:'app',
        index:'src/index'
    }
});